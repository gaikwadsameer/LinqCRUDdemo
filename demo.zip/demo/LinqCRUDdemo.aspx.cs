﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LinqCRUDdemo : System.Web.UI.Page
{
    LinqClassDataContext db = new LinqClassDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bindgrid();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        string image = Server.MapPath("~/Images/") + Guid.NewGuid() + FileUpload1.PostedFile.FileName;
        FileUpload1.PostedFile.SaveAs(image);
        string File = image.Substring(image.LastIndexOf("\\"));
        string[] split = File.Split('\\');
        string ImgPath = split[1];
        string imagepath = "~/Images/" + ImgPath;

        LinqUser LU = new LinqUser();

        LU.Name = txtName.Text;
        LU.Email = txtEmail.Text;
        LU.Image = imagepath;
        db.LinqUsers.InsertOnSubmit(LU);
        db.SubmitChanges();
        Clear();
        Bindgrid();
    }
    private void Clear()
    {
        txtName.Text = string.Empty;
        txtEmail.Text = string.Empty;
    }
    private void Bindgrid()
    {
        var bind = from c in db.LinqUsers select c;
        GridUser.DataSource = bind;
        GridUser.DataBind();
    }
    protected void GridUser_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        int ID = Convert.ToInt32(GridUser.DataKeys[e.RowIndex].Value);
        LinqUser LU = db.LinqUsers.First(x => x.Id == ID);

        db.LinqUsers.DeleteOnSubmit(LU);
        db.SubmitChanges();
        Bindgrid();
    }
    protected void GridUser_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridUser.EditIndex = e.NewEditIndex;
        Bindgrid();
    }
    protected void GridUser_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridUser.EditIndex = -1;
        Bindgrid();
    }
    protected void GridUser_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GridUser.Rows[e.RowIndex];
        TextBox txtName = (TextBox)row.FindControl("txtName");
        TextBox txtEmail = (TextBox)row.FindControl("txtEmail");

        int ID = Convert.ToInt32(GridUser.DataKeys[e.RowIndex].Value);

        LinqUser LU = db.LinqUsers.First(x => x.Id == ID);

        LU.Name = txtName.Text;
        LU.Email = txtEmail.Text;

        db.SubmitChanges();
        GridUser.EditIndex = -1;
        Bindgrid();

    }
    protected void GridUser_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridUser.PageIndex = e.NewPageIndex;
        Bindgrid();
    }  
}